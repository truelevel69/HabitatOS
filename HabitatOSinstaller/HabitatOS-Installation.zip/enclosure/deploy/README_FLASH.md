# HabitatOS — SD Card Setup Guide
## TerraNode · Raspberry Pi 5 · Official 7" Touchscreen

This guide walks you through flashing the SD card and running the installer.
No keyboard or mouse needed after the first boot.

---

## What You Need

- Raspberry Pi 5 (any RAM variant — 4GB or 8GB recommended)
- Raspberry Pi Official 7" Touchscreen
- MicroSD card — **32GB or larger, Class 10 / A2 speed rating**
- SD card reader (USB adapter or built-in laptop slot)
- Windows PC to flash the card
- Your home WiFi name and password

---

## Step 1 — Download Raspberry Pi Imager

Download and install **Raspberry Pi Imager** from:
👉 https://www.raspberrypi.com/software/

---

## Step 2 — Flash the SD Card

1. Insert your SD card into your PC
2. Open Raspberry Pi Imager
3. Click **Choose Device** → select **Raspberry Pi 5**
4. Click **Choose OS** → **Raspberry Pi OS (other)** → **Raspberry Pi OS Lite (64-bit)**
   - "Lite" = no desktop environment (exactly what we want for headless kiosk)
5. Click **Choose Storage** → select your SD card
6. Click **Next** — when asked about OS customisation, click **Edit Settings**

---

## Step 3 — Configure Settings (Critical — do this before flashing)

In the **General** tab:
| Setting | Value |
|---------|-------|
| Hostname | `terranode` |
| Username | `pi` |
| Password | *(choose a strong password — write it down)* |
| WiFi SSID | *(your home WiFi network name — exact spelling, case-sensitive)* |
| WiFi Password | *(your WiFi password)* |
| WiFi Country | `US` |
| Locale / Timezone | `America/New_York` |
| Keyboard layout | `us` |

In the **Services** tab:
| Setting | Value |
|---------|-------|
| Enable SSH | ✅ Yes |
| Allow password authentication | ✅ Yes |

Click **Save**, then click **Yes** to apply, then **Yes** to confirm flashing.

⚠️ **This erases everything on the SD card.**

Wait for flashing and verification to complete (~5–10 minutes).

---

## Step 4 — Copy HabitatOS Files

After flashing, the SD card will remount as a drive on your PC:

1. Open the SD card in File Explorer
2. Copy the entire `habitatos/` folder to the SD card root
   - The SD card should now contain a folder at `habitatos/`

Safely eject the SD card.

---

## Step 5 — First Boot

1. Insert SD card into Pi 5
2. Connect the Official 7" Touchscreen (DSI ribbon cable)
3. Power on the Pi — **no keyboard or monitor needed**
4. Wait ~90 seconds for first boot to complete
5. On your Windows PC, open a terminal (PowerShell or Command Prompt) and connect:

```
ssh pi@terranode.local
```

Enter the password you set in Step 3.

---

## Step 6 — Run the Installer

Once connected via SSH:

```bash
cd /home/pi/habitatos
bash deploy/scripts/install.sh
```

This takes about 5–10 minutes. When complete:

```bash
sudo reboot
```

---

## Step 7 — Done

After rebooting:
- The HabitatOS boot splash will appear on the touchscreen
- The dashboard will load automatically in full-screen kiosk mode
- No keyboard, no cursor, no browser chrome — just HabitatOS

**Access from your PC at any time:**
- Dashboard: `http://terranode.local:5000`
- SSH: `ssh pi@terranode.local`

---

## Troubleshooting

**Can't SSH in after first boot:**
- Wait a full 2 minutes — Pi OS does a lot on first boot
- Make sure your WiFi credentials were entered exactly right (case-sensitive)
- Try `ssh pi@terranode` (without `.local`) or find the Pi's IP in your router

**Dashboard not loading after install + reboot:**
- SSH in and check: `sudo systemctl status habitatos`
- View logs: `journalctl -u habitatos -n 50`

**Touchscreen not responding:**
- Verify DSI ribbon cable is fully seated on both ends
- The Official 7" Touchscreen requires the ribbon in DSI port 0 (closest to USB ports) on Pi 5

---

*HabitatOS v0.08 · Ripple — TerraNode build*
