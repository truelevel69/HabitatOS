#!/bin/bash
# HabitatOS Kiosk Launcher
# Targets the Raspberry Pi Official 7" Touchscreen (DSI)

# Wait for the display to be ready
sleep 2

# Disable screen blanking and power saving
xset s off
xset s noblank
xset -dpms

# Hide the mouse cursor (moves off-screen after 0.1s of inactivity)
unclutter -idle 0.1 -root &

# Wait for Flask to be ready
echo "Waiting for HabitatOS..."
until curl -s http://localhost:5000 > /dev/null 2>&1; do
    sleep 1
done
echo "HabitatOS ready — launching kiosk"

# Launch Chromium in kiosk mode
chromium-browser \
    --kiosk \
    --noerrdialogs \
    --disable-infobars \
    --disable-session-crashed-bubble \
    --disable-restore-session-state \
    --no-first-run \
    --check-for-update-interval=31536000 \
    --disable-pinch \
    --overscroll-history-navigation=0 \
    --disable-features=TranslateUI \
    --disable-context-menu \
    --touch-events=enabled \
    --enable-features=OverlayScrollbar \
    --app=http://localhost:5000
