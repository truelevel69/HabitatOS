#!/bin/bash
# ══════════════════════════════════════════════════════════════════════════════
#  HabitatOS Install Script
#  Raspberry Pi 5 · Raspberry Pi Official 7" Touchscreen · Headless Kiosk
#
#  Run as: bash install.sh
#  Do NOT run with sudo — the script will request sudo where needed.
# ══════════════════════════════════════════════════════════════════════════════

set -e

HABITATOS_DIR="/home/pi/habitatos"
VENV_DIR="$HABITATOS_DIR/venv"
DEPLOY_DIR="$HABITATOS_DIR/deploy"

GREEN='\033[0;32m'
AMBER='\033[0;33m'
RED='\033[0;31m'
DIM='\033[2m'
NC='\033[0m'

ok()   { echo -e "${GREEN}  ✓  ${NC}$1"; }
info() { echo -e "${DIM}  →  ${NC}$1"; }
warn() { echo -e "${AMBER}  ⚠  ${NC}$1"; }
fail() { echo -e "${RED}  ✗  ${NC}$1"; exit 1; }

echo ""
echo -e "${GREEN}══════════════════════════════════════════════${NC}"
echo -e "${GREEN}  HabitatOS — Enclosure Monitor              ${NC}"
echo -e "${GREEN}  Install Script · v0.08 · Ripple            ${NC}"
echo -e "${GREEN}══════════════════════════════════════════════${NC}"
echo ""

# ── 1. Verify running on Pi ───────────────────────────────────────────────────
info "Checking hardware..."
if ! grep -q "Raspberry Pi" /proc/cpuinfo 2>/dev/null; then
    warn "Not running on a Raspberry Pi — some steps may be skipped."
fi
ok "Hardware check complete"

# ── 2. System update ──────────────────────────────────────────────────────────
info "Updating system packages (this may take a few minutes)..."
sudo apt-get update -qq
sudo apt-get upgrade -y -qq
ok "System updated"

# ── 3. Install dependencies ───────────────────────────────────────────────────
info "Installing system dependencies..."
sudo apt-get install -y -qq \
    python3 python3-pip python3-venv \
    chromium-browser \
    unclutter \
    xserver-xorg x11-xserver-utils xinit openbox \
    plymouth plymouth-themes \
    curl git
ok "System dependencies installed"

# ── 4. Python virtual environment ────────────────────────────────────────────
info "Creating Python virtual environment..."
python3 -m venv "$VENV_DIR"
"$VENV_DIR/bin/pip" install --upgrade pip -q
"$VENV_DIR/bin/pip" install -r "$HABITATOS_DIR/requirements.txt" -q
ok "Python environment ready"

# ── 5. Auto-login (no keyboard needed on boot) ───────────────────────────────
info "Configuring auto-login for user pi..."
sudo mkdir -p /etc/systemd/system/getty@tty1.service.d
sudo tee /etc/systemd/system/getty@tty1.service.d/autologin.conf > /dev/null << 'EOF'
[Service]
ExecStart=
ExecStart=-/sbin/agetty --autologin pi --noclear %I $TERM
EOF
ok "Auto-login configured"

# ── 6. Auto-start X and kiosk on login ───────────────────────────────────────
info "Configuring kiosk auto-start..."
cat >> /home/pi/.bashrc << 'EOF'

# HabitatOS kiosk auto-start
if [ -z "$DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
    startx /home/pi/habitatos/deploy/scripts/kiosk.sh -- -nocursor 2>/dev/null
fi
EOF
ok "Kiosk auto-start configured"

# ── 7. Make kiosk script executable ──────────────────────────────────────────
chmod +x "$DEPLOY_DIR/scripts/kiosk.sh"
ok "Kiosk script permissions set"

# ── 8. Install Flask systemd service ─────────────────────────────────────────
info "Installing HabitatOS systemd service..."
sudo cp "$DEPLOY_DIR/systemd/habitatos.service" /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable habitatos.service
ok "HabitatOS service installed and enabled"

# ── 9. Plymouth boot splash ───────────────────────────────────────────────────
info "Installing HabitatOS boot splash..."
sudo cp -r "$DEPLOY_DIR/plymouth/habitatos" /usr/share/plymouth/themes/
sudo plymouth-set-default-theme -R habitatos 2>/dev/null || \
    warn "Plymouth theme install skipped (may need to run: sudo plymouth-set-default-theme -R habitatos)"
ok "Boot splash installed"

# ── 10. Boot config for Official 7" touchscreen ──────────────────────────────
info "Configuring display for Official Raspberry Pi 7\" Touchscreen..."
BOOT_CONFIG="/boot/firmware/config.txt"
if [ -f "$BOOT_CONFIG" ]; then
    # Ensure DSI display is active
    sudo sed -i '/^#\?dtoverlay=vc4-kms-v3d/s/.*/dtoverlay=vc4-kms-v3d/' "$BOOT_CONFIG" 2>/dev/null || true
    # Disable display_auto_detect if set (can conflict with official touchscreen)
    grep -q "display_auto_detect" "$BOOT_CONFIG" || echo "display_auto_detect=1" | sudo tee -a "$BOOT_CONFIG" > /dev/null
    ok "Display configured for Official 7\" Touchscreen"
else
    warn "Boot config not found at $BOOT_CONFIG — display config skipped"
fi

# ── 11. Disable screensaver and power management ──────────────────────────────
info "Disabling screen blanking..."
sudo tee /etc/X11/xorg.conf.d/10-noblank.conf > /dev/null << 'EOF'
Section "ServerFlags"
    Option "BlankTime"   "0"
    Option "StandbyTime" "0"
    Option "SuspendTime" "0"
    Option "OffTime"     "0"
EndSection
EOF
ok "Screen blanking disabled"

# ── 12. SSH ───────────────────────────────────────────────────────────────────
info "Ensuring SSH is enabled..."
sudo systemctl enable ssh
sudo systemctl start ssh
ok "SSH enabled — connect with: ssh pi@terranode.local"

# ── 13. Set hostname ──────────────────────────────────────────────────────────
info "Setting hostname to terranode..."
sudo hostnamectl set-hostname terranode
sudo sed -i 's/127\.0\.1\.1.*/127.0.1.1\tterranode/' /etc/hosts 2>/dev/null || true
ok "Hostname set to terranode"

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}══════════════════════════════════════════════${NC}"
echo -e "${GREEN}  HabitatOS installation complete!           ${NC}"
echo -e "${GREEN}══════════════════════════════════════════════${NC}"
echo ""
echo -e "  Dashboard:  ${GREEN}http://terranode.local:5000${NC}"
echo -e "  SSH access: ${GREEN}ssh pi@terranode.local${NC}"
echo ""
echo -e "${AMBER}  Reboot now to start HabitatOS:${NC}"
echo -e "  ${DIM}sudo reboot${NC}"
echo ""
